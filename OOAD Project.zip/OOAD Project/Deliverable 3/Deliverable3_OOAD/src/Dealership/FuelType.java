package Dealership;

public enum FuelType {

    PETROL,

    DIESEL,

    ELECTRIC
}
