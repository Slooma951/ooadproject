package Dealership;

public enum ServiceType {

    INSURANCE,

    NCT,

    FUEL,

    MAINTENANCE
}
