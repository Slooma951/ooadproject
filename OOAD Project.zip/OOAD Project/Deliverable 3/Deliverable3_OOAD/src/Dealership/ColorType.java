package Dealership;

public enum ColorType {

    RED,

    WHITE,

    GREY,

    GREEN,

    BLUE,

    ORANGE,

    PURPLE
}
