package Dealership;

public enum MakeType {

    TOYOTA,

    NISSAN,

    SRT,

    FORD,

    TESLA,
}
