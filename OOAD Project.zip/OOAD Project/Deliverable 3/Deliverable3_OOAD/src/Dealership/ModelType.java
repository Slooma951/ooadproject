package Dealership;

public enum ModelType {

    SEDAN,

    SUV,

    TRUCK,

    SPORT
}
