package Dealership;

public enum ConditionType {

    LIKE_NEW,

    USED,

    JUNK
}
