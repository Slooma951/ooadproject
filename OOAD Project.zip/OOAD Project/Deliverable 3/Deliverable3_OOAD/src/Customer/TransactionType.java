package Customer;


public enum TransactionType {
    CASH,
    CREDITCARD,
    DEBITCARD,
    MASTERCARD


}
